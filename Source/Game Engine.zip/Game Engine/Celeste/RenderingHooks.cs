﻿using System.Collections.Generic;
using Celeste.Mod.Helpers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoMod.Cil;


namespace Celeste.Mod.Celeste3DEngine;

internal class RenderingHooks
{
    internal static Renderer3D activeRenderer = null;
    
    internal static void AddRenderer(Renderer3D renderer) => activeRenderer = renderer;

	public static void ON_HUD_RenderHD(On.Celeste.Level.orig_Render orig, Level self)
	{
		orig(self);
		if (activeRenderer != null)
			activeRenderer.RenderOverlayCanvases();
	}

	public static void IL_Level_Render(ILContext il)
	{
		ILCursor cursor = new(il);
		IL_Level_Render_3D(cursor);
		cursor.Index = 0;
		IL_Level_Render_3D_HD(cursor);
	}
    
    public static void IL_Level_Render_3D(ILCursor c) 
    {
	    if (c.TryGotoNextBestFit(MoveType.Before,instr => instr.MatchCall(typeof(Distort), nameof(Level.Render))))
	    {
		    c.EmitLdarg0();
		    c.EmitDelegate(Render3D);	
	    }
	    else
		    Logger.Log(LogLevel.Error, "Celeste3DEngine", "Failed to instert Render 3D hook");
	    
	    
    }
    
    public static void IL_Level_Render_3D_HD(ILCursor c) 
    {
	    if (c.TryGotoNextBestFit(MoveType.Before,
		        instr => instr.MatchLdnull(),
		        instr => instr.MatchCallvirt<GraphicsDevice>(nameof(GraphicsDevice.SetRenderTarget))
	        )
	        && c.TryGotoNextBestFit(MoveType.Before, instr => instr.MatchCallvirt<SpriteBatch>(nameof(SpriteBatch.Begin)))) 
	    {
		    c.EmitLdarg0();
		    c.EmitDelegate(Render3DHD);
	    }
	    else
		    Logger.Log(LogLevel.Error, "Celeste3DEngine", "Failed to insert Render 3D HD hook");
    }
    
    static void Render3D(Level level) 
    {
	    if (activeRenderer != null && !activeRenderer.isHDMode)
		    activeRenderer.RenderNonHD();
    }
    
    static void Render3DHD(Level level) 
    {
	    if (activeRenderer != null && activeRenderer.isHDMode)
	    {
		    level.BackgroundColor = Color.Transparent;
		    activeRenderer.RenderHD();
	    }
    }
}