﻿namespace Celeste.Mod.Celeste3DEngine;

public class MeshRenderer
{
    internal GameObject gameObject;
    
    internal ModelFormat format = ModelFormat.UNKNOWN;
    
    internal Model3D model;
    internal Model3D GetModel() => model;
    internal void SetModel(Model3D m) => model = m;
    
    internal Material material = Material.DefaultMaterial;
    
    internal string modelName;
    internal string textureName;
    
    internal bool useEngineModelPath = false;
    internal bool useEngineTexturePath = false;
    
    internal ModelLayer layer;
    
    /// <summary> Whether this Model casts shadows </summary>
    public bool castsShadows = true;
    
    /// <summary> Whether this Model receives shadows </summary>
    public bool receivesShadows = true;
    
    internal Material InstanceMaterial
    {
        get
        {
            if (ReferenceEquals(material, Material.DefaultMaterial))
                material = material.Clone();
            return material;
        }
    }
    
    public MeshRenderer(string modelName, string textureName, ModelLayer modelLayer = ModelLayer.World)
    {
        this.modelName = modelName;
        this.textureName = textureName;
        layer = modelLayer;
    }

    public MeshRenderer(string modelName, ModelLayer modelLayer = ModelLayer.World)
    {
        this.modelName = modelName;
        layer = modelLayer;
    }
    
    public MeshRenderer(string modelName, string textureName, Material mat, ModelLayer modelLayer = ModelLayer.World)
        : this(modelName, textureName, modelLayer)
    {
        SetMaterial(mat);
    }
    
    public MeshRenderer(string modelName, Material mat, ModelLayer modelLayer = ModelLayer.World)
        : this(modelName, modelLayer)
    {
        SetMaterial(mat);
    }
    
    /// <summary> Changes the texture of this Model at runtime. </summary>
    public void ChangeTexture(string newTexturePath)
    {
        textureName = newTexturePath;
        useEngineTexturePath = false;
        model?.ChangeTexture(newTexturePath);
    }
    
    /// <summary> Changes the model of this Model at runtime. </summary>
    public void ChangeModel(string newModelPath)
    {
        modelName = newModelPath;
        useEngineModelPath = false;
        model?.ChangeModel(newModelPath);
    }
    
    /// <summary> Changes the layer of this Model at runtime. </summary>
    public void ChangeLayer(ModelLayer newLayer)
    {
        if (gameObject?.scene == null) return;
        model?.UpdateLayer();
        layer = newLayer;
    }
    
    /// <summary> Returns the Material of this Object </summary>
    public Material GetMaterial() => InstanceMaterial;
    
    /// <summary> Sets the material for this Model. If null is passed, the DefaultMaterial will be used. </summary>
    public void SetMaterial(Material mat) => material = mat ?? Material.DefaultMaterial;
}

enum ModelFormat
{
    OBJ,
    GLTF,
    UNKNOWN
}