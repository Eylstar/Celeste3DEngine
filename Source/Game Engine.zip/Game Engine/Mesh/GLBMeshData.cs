﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monocle;
using SharpGLTF.Memory;
using SharpGLTF.Schema2;
using Vector2 = System.Numerics.Vector2;
using Vector3 = System.Numerics.Vector3;
using Vector4 = System.Numerics.Vector4;

namespace Celeste.Mod.Celeste3DEngine;


internal sealed class GLBMeshData : MeshData
{
    string cacheKey;
    internal static Dictionary<string, CashedMeshEntry> meshCache = new();
    
    internal List<CustomPrimitive> primitives = new();
    internal GLBNodeHierarchy hierarchy;
    
    internal static GLBMeshData CreateFromStream(Stream stream, string modelName)
    {
        if (meshCache.TryGetValue(modelName, out CashedMeshEntry meshEntry))
        {
            Logger.Info("GLBMeshData", $"Using cached mesh for '{modelName}'");
            
            meshEntry.referenceCount++;
            meshEntry.meshData.cacheKey = modelName;
            return meshEntry.meshData;
        }
        else
        {
            GLBMeshData meshData = ParseMesh(stream);
            meshCache[modelName] = new CashedMeshEntry { meshData = meshData, referenceCount = 1 };
            meshData.cacheKey = modelName;
            return meshData;
        }
    }
    
    // Read GLB using SharpGLTF, extract vertex data, create buffers and textures
    static GLBMeshData ParseMesh(Stream stream)
    {
        if (stream.CanSeek) stream.Seek(0, SeekOrigin.Begin);
        
        GraphicsDevice device = Engine.Instance.GraphicsDevice;
        GLBMeshData meshData = new GLBMeshData();
        
        // Cache for loaded textures to avoid duplicate loading from stream
        Dictionary<string, Texture2D> loadedTextures = new Dictionary<string, Texture2D>();
        
        var settings = new ReadSettings { Validation = SharpGLTF.Validation.ValidationMode.Skip };
        
        ModelRoot model = ModelRoot.ReadGLB(stream, settings);
        
        float maxRadius = 0f;

        foreach (Node node in model.LogicalNodes)
        {
            if (node.Mesh == null) continue;
            
            Matrix4x4 nodeMatrix = node.WorldMatrix;
            Matrix4x4.Invert(nodeMatrix, out var invNodeMatrix);

            foreach (MeshPrimitive gltfPrim in node.Mesh.Primitives)
            {
                var positions = gltfPrim.GetVertexAccessor("POSITION").AsVector3Array();
                var normals = gltfPrim.GetVertexAccessor("NORMAL")?.AsVector3Array();
                var uvs = gltfPrim.GetVertexAccessor("TEXCOORD_0")?.AsVector2Array();
                var indices = gltfPrim.GetIndexAccessor().AsIndicesArray();
                
                var joints = gltfPrim.GetVertexAccessor("JOINTS_0")?.AsVector4Array();
                var weights = gltfPrim.GetVertexAccessor("WEIGHTS_0")?.AsVector4Array();
                bool isSkinned = joints != null && weights != null && node.Skin != null;

                if (isSkinned)
                {
                    Logger.Info("GLBMeshData", $"Mesh '{node.Name}' has skinning data, but skinned rendering is not yet supported. Rendering without skinning.");
                    var skinnedVertices = new SkinnedVertex[positions.Count];
                    for (int i = 0; i < positions.Count; i++)
                    {
                        Vector3 pos = positions[i];
                        Vector3 normal = normals != null ? normals[i] : Vector3.UnitY;
                        Vector2 uv = uvs != null ? new Vector2(uvs[i].X, uvs[i].Y) : Vector2.Zero;
                        
                        skinnedVertices[i] = new SkinnedVertex(pos, normal, uv, joints[i], weights[i]);
                        
                        float radius = pos.LengthSquared();
                        if (radius > maxRadius) maxRadius = radius;
                    }
                    
                    VertexBuffer vertBuffer = new VertexBuffer(device, SkinnedVertex.VertexDeclaration, skinnedVertices.Length, BufferUsage.None);
                    vertBuffer.SetData(skinnedVertices);
                    
                    Skin skin = node.Skin;
                    int boneCount = skin.Joints.Count;
                    Matrix[] invBindMatrices = new Matrix[boneCount];
                    int[] nodeIndices = new int[boneCount];
                    
                    for (int j = 0; j < boneCount; j++)
                    {
                        (Node jointNode, Matrix4x4 invBind) = skin.GetJoint(j);
                        invBindMatrices[j] = XNAHelper.ToXNA(invBind);
                        nodeIndices[j] = jointNode.LogicalIndex;
                    }
                    
                    uint[] indexArray = new uint[indices.Count];
                    for (int i = 0; i < indices.Count; i++)
                        indexArray[i] = indices[i];
                    
                    
                    IndexBuffer indexBuffer = new IndexBuffer(device, IndexElementSize.ThirtyTwoBits, indexArray.Length, BufferUsage.None);
                    indexBuffer.SetData(indexArray);
                    
                    Texture2D t = ExtractTexture(gltfPrim, loadedTextures);
                    
                    SkinnedPrimitive prim = new SkinnedPrimitive
                    {
                        vertBuffer = vertBuffer,
                        indexBuffer = indexBuffer,
                        texture = t,
                        inverseBindMatricesl = invBindMatrices,
                        nodeIndices = nodeIndices,
                        indexCount = indexArray.Length
                    };
                    
                    meshData.primitives.Add(prim);
                }
                else
                {
                    var vertices = new VertexPositionNormalTexture[positions.Count];
                    for (int i = 0; i < positions.Count; i++)
                    {
                        Vector3 rawPos = positions[i];
                        Vector3 transPos = Vector3.Transform(rawPos, nodeMatrix);
                        Vector3 pos = new Vector3(transPos.X, transPos.Y, transPos.Z);
                        
                        Vector3 rawNormal = normals != null ? normals[i] : Vector3.UnitY;
                        Vector3 transNormal = Vector3.TransformNormal(rawNormal, Matrix4x4.Transpose(invNodeMatrix));
                        Vector3 normal = new Vector3(transNormal.X, transNormal.Y, transNormal.Z);
                        normal = Vector3.Normalize(normal);
                        
                        Vector2 uv = uvs != null ? new Vector2(uvs[i].X, uvs[i].Y) : Vector2.Zero;
                        
                        vertices[i] = new VertexPositionNormalTexture(XNAHelper.ToXNA(pos), XNAHelper.ToXNA(normal), XNAHelper.ToXNA(uv));
                        
                        float radius = pos.LengthSquared();
                        if (radius > maxRadius) maxRadius = radius;
                    }
                    
                    uint[] indexArray = new uint[indices.Count];
                    for (int i = 0; i < indices.Count; i++)
                        indexArray[i] = indices[i];
                    
                    
                    
                    VertexBuffer vertBuffer = new VertexBuffer(device, typeof(VertexPositionNormalTexture), vertices.Length, BufferUsage.None);
                    vertBuffer.SetData(vertices);
                    
                    IndexBuffer indexBuffer = new IndexBuffer(device, IndexElementSize.ThirtyTwoBits, indexArray.Length, BufferUsage.None);
                    indexBuffer.SetData(indexArray);

                    Texture2D t = ExtractTexture(gltfPrim, loadedTextures);
                    
                    CustomPrimitive prim = new CustomPrimitive
                    {
                        vertBuffer = vertBuffer,
                        indexBuffer = indexBuffer,
                        indexCount = indexArray.Length,
                        texture = t
                    };
                    
                    meshData.primitives.Add(prim);
                }
            }
        }
        
        var nodes = model.LogicalNodes;
        GLBNodeHierarchy hierarchy = new GLBNodeHierarchy
        {
            nodeCount = nodes.Count,
            parentIndices = new int[nodes.Count],
            localBindPoses = new Matrix[nodes.Count]
        };
            
        for (int i = 0; i < nodes.Count; i++)
        {
            Node n = nodes[i];
            hierarchy.parentIndices[i] = n.VisualParent?.LogicalIndex ?? -1;
            hierarchy.localBindPoses[i] = XNAHelper.ToXNA(n.LocalMatrix);
        }
            
        meshData.hierarchy = hierarchy;
        
        meshData.boundingSphereRadius = MathF.Sqrt(maxRadius);
        
        return meshData;
    }

    static Texture2D ExtractTexture(MeshPrimitive prim, Dictionary<string, Texture2D> loadedTextures)
    {
        Texture2D t = null;
        GraphicsDevice device = Engine.Instance.GraphicsDevice;
                    
        MaterialChannel? baseColorChannel = prim.Material?.FindChannel("BaseColor");
        MemoryImage? baseColorImage = baseColorChannel?.Texture?.PrimaryImage?.Content;
                    
        //Texture
        if (baseColorImage != null && !baseColorImage.Value.Content.IsEmpty)
        {
            //Try to reuse already loaded texture if possible
            string textureKey = baseColorChannel.Value.Texture.LogicalIndex.ToString();
            if (!loadedTextures.TryGetValue(textureKey, out t))
            {
                byte[] imageData = baseColorImage.Value.Content.ToArray();
                using MemoryStream ms = new MemoryStream(imageData);
                t = Texture2D.FromStream(device, ms);
                loadedTextures[textureKey] = t;
            }
        }
        //Fallback to base color factor if texture is missing
        else if (baseColorChannel != null)
        {
            Vector4 factor = (Vector4)baseColorChannel.Value.Parameters[0].Value;
            t = new Texture2D(device, 1, 1);
            t.SetData(new[] { new Microsoft.Xna.Framework.Color(factor.X, factor.Y, factor.Z, factor.W) });
        }
        
        return t;
    }

    internal override void DrawWithSetup(Effect effect, Action<Texture2D> onBeforePrimitive)
    {
        GraphicsDevice device = Engine.Instance.GraphicsDevice;
        foreach (CustomPrimitive prim in primitives)
        {
            if (prim.vertBuffer == null || prim.vertBuffer.IsDisposed) continue;
            
            onBeforePrimitive(prim.texture);

            device.SetVertexBuffer(prim.vertBuffer); 
            device.Indices = prim.indexBuffer;

            foreach (var pass in effect.CurrentTechnique.Passes)
            {
                pass.Apply(); 
                device.DrawIndexedPrimitives(Microsoft.Xna.Framework.Graphics.PrimitiveType.TriangleList, 0, 0, prim.vertBuffer.VertexCount, 0, prim.indexCount / 3);
            }
        }
    }

    public override void Dispose()
    {
        if (meshCache.TryGetValue(cacheKey, out CashedMeshEntry meshEntry))
        {
            int newRefCount = meshEntry.referenceCount - 1;
            if (newRefCount <= 0)
            {
                foreach (CustomPrimitive prim in meshEntry.meshData.primitives)
                {
                    prim.vertBuffer?.Dispose();
                    prim.indexBuffer?.Dispose();
                    prim.texture?.Dispose();
                }

                primitives.Clear();
                meshCache.Remove(cacheKey);
            }
            else
            {
                meshEntry.referenceCount = newRefCount;
            }
        }
    }
    
    internal static void ClearCache()
    {
        foreach (var entry in meshCache.Values)
        {
            foreach (CustomPrimitive prim in entry.meshData.primitives)
            {
                prim.vertBuffer?.Dispose();
                prim.indexBuffer?.Dispose();
                prim.texture?.Dispose();
            }
            entry.meshData?.primitives?.Clear();
        }
        meshCache?.Clear();
    }
}

internal class CashedMeshEntry
{
    internal GLBMeshData meshData;
    internal int referenceCount;
}


// Class used to represent and store primitive data
internal class CustomPrimitive
{
    internal VertexBuffer vertBuffer;
    internal IndexBuffer indexBuffer;
    internal Texture2D texture;
    internal int indexCount;
}

// Class used to represent and store skinned primitive data
internal sealed class SkinnedPrimitive : CustomPrimitive
{
    internal Matrix[] inverseBindMatricesl;
    internal int[] nodeIndices;
}

// Node hierarchy and bind pose data for skinned meshes
internal sealed class GLBNodeHierarchy
{
    internal int nodeCount;
    internal int[] parentIndices;
    internal Matrix[] localBindPoses;
}

// Vertex structure for skinned meshes, includes joint indices and weights for skinning calculations in shader
internal struct SkinnedVertex : IVertexType
{
    public Vector3 Position;
    public Vector3 Normal;
    public Vector2 UV;
    public Vector4 Joints;
    public Vector4 Weights;
    
    internal SkinnedVertex(Vector3 position, Vector3 normal, Vector2 uv, Vector4 joints, Vector4 weights)
    {
        Position = position;
        Normal = normal;
        UV = uv;
        Joints = joints;
        Weights = weights;
    }
    
    internal static readonly VertexDeclaration VertexDeclaration = new VertexDeclaration
    (
        new VertexElement(0, VertexElementFormat.Vector3, VertexElementUsage.Position, 0),
        new VertexElement(12, VertexElementFormat.Vector3, VertexElementUsage.Normal, 0),
        new VertexElement(24, VertexElementFormat.Vector2, VertexElementUsage.TextureCoordinate, 0),
        new VertexElement(32, VertexElementFormat.Vector4, VertexElementUsage.BlendIndices, 0),
        new VertexElement(48, VertexElementFormat.Vector4, VertexElementUsage.BlendWeight, 0)
    );
    
    VertexDeclaration IVertexType.VertexDeclaration => VertexDeclaration;
}