﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Monocle;

namespace Celeste.Mod.Celeste3DEngine;

//public class GraphicGameObject : GameObject
//{
    /*
    /// <summary> Creates a simple cube with the default texture. Useful for testing purposes. </summary>
    public static GraphicGameObject DefaultCube()
    {
        GraphicGameObject go = new GraphicGameObject("cube", "defaultTexture", Vector3.Zero, Vector3.Zero, Vector3.One, ModelLayer.World, "Cube");
        go.useEngineModelPath = true;
        go.useEngineTexturePath = true;
        go.material = Material.DefaultMaterial;
        return go;
    }
    
    /// <summary> Creates a simple sphere with the default texture. Useful for testing purposes. </summary>
    public static GraphicGameObject DefaultSphere()
    {
        GraphicGameObject go = new GraphicGameObject("quad", "defaultTexture", Vector3.Zero, Vector3.Zero, Vector3.One, ModelLayer.World, "Quad");
        go.useEngineModelPath = true;
        go.useEngineTexturePath = true;
        go.material = Material.DefaultMaterial;
        return go;
    }

    /// <summary> Creates a simple plane with the default texture. Useful for testing purposes. </summary>
    public static GraphicGameObject DefaultPlane()
    {
        GraphicGameObject go = new GraphicGameObject("plane", "defaultTexture", Vector3.Zero, Vector3.Zero, Vector3.One, ModelLayer.World, "Plane");
        go.useEngineModelPath = true;
        go.useEngineTexturePath = true;
        go.material = Material.DefaultMaterial;
        return go;
    }
    */
//}